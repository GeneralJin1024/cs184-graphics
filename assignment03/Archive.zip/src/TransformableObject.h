#ifndef __TRANSFORMABLE_OBJECT_H
#define __TRANSFORMABLE_OBJECT_H

#include "include.h"

class TransformableObject {
 public:
 	TransformableObject() {
 		r = rand() * 1.0 / RAND_MAX;
	    g = rand() * 1.0 / RAND_MAX;
	    b = rand() * 1.0 / RAND_MAX;
	    trasnformation = Transform<T, 3, Affine>::Identity();
 	}
 	~TransformableObject() = default;

 	Transform<T, 3, Affine> transformation;
 	T r, g, b;
};

#endif